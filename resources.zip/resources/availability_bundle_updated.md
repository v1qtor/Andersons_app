# Availability Bundle (Updated)

This file includes the current `ScheduleCalendar` backend code (copied), references to the frontend Blade view and the task form modal used for availability, plus the `UnavailabilityPeriod` model and a suggested server-side enforcement snippet.

---

## File: app/Livewire/Schedule/ScheduleCalendar.php

```php
<?php

namespace App\Livewire\Schedule;

use App\Livewire\Schedule\CollaborationSchedule;
use App\Livewire\Schedule\CrudSchedule;
use App\Livewire\Schedule\PrintSchedule;
use App\Models\Birthdate;
use App\Models\CollaborationRequest;
use App\Models\Location;
use App\Models\PlannedMeal;
use App\Models\Task;
use App\Models\TaskCategory;
use App\Models\TaskPriority;
use App\Models\Trip;
use App\Models\UnavailabilityPeriod;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Layout;
use Livewire\Component;

#[Layout('components.layouts.app')]
class ScheduleCalendar extends Component
{
    use PrintSchedule, CrudSchedule, CollaborationSchedule;

    public string $view = 'week'; // day, week, month

    public int $year;
    public int $month;
    public int $day;

    public array $selectedPeople = [];

    public bool $showMyTasksOnly = false;

    public string $myTaskOwnershipFilter = 'all'; // 'all', 'owner', 'not-owned'

    public ?string $selectedDay = null;

    public function mount(): void
    {
        $today = Carbon::today();
        $this->year = $today->year;
        $this->month = $today->month;
        $this->day = $today->day;
    }

    public function setView(string $view): void
    {
        $this->view = $view;
    }

    public function previousPeriod(): void
    {
        if ($this->view === 'month') {
            $date = Carbon::create($this->year, $this->month, 1)->subMonth();
        } else {
            $date = Carbon::create($this->year, $this->month, $this->day);
            match ($this->view) {
                'day' => $date->subDay(),
                'week' => $date->subWeek(),
            };
        }

        $this->year = $date->year;
        $this->month = $date->month;
        $this->day = $date->day;
        $this->selectedDay = null;
    }

    public function nextPeriod(): void
    {
        if ($this->view === 'month') {
            $date = Carbon::create($this->year, $this->month, 1)->addMonth();
        } else {
            $date = Carbon::create($this->year, $this->month, $this->day);
            match ($this->view) {
                'day' => $date->addDay(),
                'week' => $date->addWeek(),
            };
        }

        $this->year = $date->year;
        $this->month = $date->month;
        $this->day = $date->day;
        $this->selectedDay = null;
    }

    public function goToToday(): void
    {
        $today = Carbon::today();
        $this->year = $today->year;
        $this->month = $today->month;
        $this->day = $today->day;
        $this->selectedDay = null;
    }

    public function togglePerson(int $userId): void
    {
        if (in_array($userId, $this->selectedPeople)) {
            $this->selectedPeople = array_values(array_diff($this->selectedPeople, [$userId]));
        } else {
            $this->selectedPeople[] = $userId;
        }
    }

    public function clearFilters(): void
    {
        $this->selectedPeople = [];
    }

    public function setMyTasksOnly(bool $value): void
    {
        $this->showMyTasksOnly = $value;
        // Reset ownership filter when switching between My Tasks / All Tasks
        $this->myTaskOwnershipFilter = 'all';
    }

    public function setMyTaskOwnershipFilter(string $filter): void
    {
        $this->myTaskOwnershipFilter = $filter;
    }

    public function openDay(string $date): void
    {
        $this->selectedDay = $date;
    }

    public function closeDay(): void
    {
        $this->selectedDay = null;
    }

    private function isAdmin(): bool
    {
        return Auth::user()->role && Auth::user()->role->name === 'Admin';
    }

    private function canManageTask(Task $task): bool
    {
        if ($this->isAdmin()) {
            return true;
        }

        return $task->users()
            ->where('users.id', Auth::id())
            ->wherePivot('is_owner', true)
            ->exists();
    }

    /**
     * Get the date range for the current view.
     */
    private function getDateRange(): array
    {
        return match ($this->view) {
            'day' => [
                Carbon::create($this->year, $this->month, $this->day)->startOfDay(),
                Carbon::create($this->year, $this->month, $this->day)->endOfDay(),
            ],
            'week' => [
                Carbon::create($this->year, $this->month, $this->day)->startOfWeek(Carbon::MONDAY),
                Carbon::create($this->year, $this->month, $this->day)->endOfWeek(Carbon::SUNDAY),
            ],
            'month' => [
                Carbon::create($this->year, $this->month, 1)->startOfDay(),
                Carbon::create($this->year, $this->month, 1)->endOfMonth()->endOfDay(),
            ],
        };
    }

    // ... (rest of the class methods are unchanged; full file in repo)
```

---

## File references (frontend)
- Blade component: `resources/views/components/schedule-calendar.blade.php` (live view used by `ScheduleCalendar`)
- Task form modal: `resources/views/components/task-form-modal.blade.php` (used to create/edit tasks and hides unavailable users)
- Parent Livewire inclusion: `resources/views/livewire/schedule.blade.php` (contains `<livewire:schedule.schedule-calendar />`)

---

## File: app/Models/UnavailabilityPeriod.php

```php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class UnavailabilityPeriod extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'start_date',
        'end_date',
        'description',
    ];

    protected function casts(): array
    {
        return [
            'start_date' => 'datetime',
            'end_date'   => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
```

---

Notes and enforcement suggestion

- The frontend `task-form-modal` hides users present in `unavailableUserIds` so they can't be selected in the UI.
- The `ScheduleCalendar` computes `$unavailableUserIds` in `render()` using:

```php
$unavailableUserIds = UnavailabilityPeriod::where('start_date', '<', $taskEnd)
    ->where('end_date', '>', $taskStart)
    ->pluck('user_id')
    ->unique()
    ->toArray();
```

- To fully enforce the rule (prevent assigning tasks to unavailable users even via crafted requests), add server-side validation inside the `saveTask()` flow (before syncing users) that rejects or removes unavailable users.

Suggested snippet to insert into `saveTask()` for admin assignment flows:

```php
$taskStart = $startDt;
$taskEnd = $endDt ?: $startDt->copy()->addHour();
$unavailable = UnavailabilityPeriod::where('start_date', '<', $taskEnd)
    ->where('end_date', '>', $taskStart)
    ->pluck('user_id')
    ->unique()
    ->toArray();
$conflicting = array_intersect($this->assignedUserIds, $unavailable);
if (! empty($conflicting)) {
    throw \Illuminate\Validation\ValidationException::withMessages([
        'assignedUserIds' => [__('Some selected users are unavailable during the selected time.')],
    ]);
}
```

If you want, I can apply this server-side check directly into `app/Livewire/Schedule/CrudSchedule.php` or into `ScheduleCalendar::saveTask()` depending on whether that method lives in the `CrudSchedule` trait now.

---

File created: `resources/availability_bundle_updated.md`

Would you like me to also add the server-side enforcement now? If so, I can patch the trait or `saveTask()` and run a quick static check.  