User Guide — Availability & Task Assignment (Frontend)

This guide explains, in plain British English, what each main page and control does when you want to check someone’s availability or assign a task.

Quick summary

- If a person is marked unavailable for the chosen task time, you cannot assign them directly. Their name is hidden in the owner/assigned lists. You can still send a collaboration request so they are notified.

Schedule page (main calendar)

- Where it is: open the app and choose "Schedule" from the menu to see the household calendar.
- Top-left: three buttons labelled Day, Week, Month. Use these to change the calendar view.
- Top-right of the header: the "New Task" button. Click this to open the task form modal.
- Just under the header: the "Filter by person" area — click a name to show only that person’s items on the calendar.
- Incoming collaboration requests appear at the top of the page when you have them. Each request shows the task, who asked and two buttons: Accept and Decline.

How to create a task and check availability (step-by-step)

1. Click the "New Task" button (top-right of the calendar header).
2. Set the Start Date & Time and End Date & Time in the form — these are the times the task will take place.
3. Look at the Task Owner section (admins only) and the Assigned Users section:
   - If a person’s name appears, they are available and you can click their name to select them.
   - If a person’s name does not appear, they are unavailable for the chosen times and cannot be picked.
4. If you are not an admin, use the "Request Collaboration" area to notify people. Click the names to send requests.
5. Click "Create Task" (or "Update Task") at the bottom-right of the form to save.

What the UI shows when someone is unavailable

- Unavailable people are not shown in the Owner, Assigned Users, or Request Collaboration lists when the times overlap their unavailable period.
- If an administrator tries to force an assignment (for example via a scripted request), the system will prevent the save and show a message: "One or more selected users are unavailable during this period." Change the task time or choose other people.

Editing or assigning an existing task

- Open a day by clicking any day cell on the calendar. This opens the Day Details modal with a list of trips, tasks and meals.
- On each task card you will see action buttons (if you are allowed to edit): a pencil icon to edit and a trash icon to delete. These are on the right of the task card.
- To edit, click the pencil icon. The same availability rules apply in the edit form: unavailable users will be hidden.

Accepting collaboration requests

- Incoming requests show in the top area of the Schedule page. Each request card has Accept and Decline buttons. Accept will add the person to the task.

Other helpful controls

- Filter by person: use the small buttons below the header to focus the calendar on one or more users.
- Today: a "Today" button near the period label returns the view to the current day/week/month.

Common scenarios and tips

- If someone is on holiday, pick another available person or change the task date.
- If you must notify an unavailable person, use Request Collaboration so they see the task and can accept later.
- If you do not see someone in the lists, check the task start/end times first — that is usually why they are missing.

Troubleshooting messages (what to do)

- "One or more selected users are unavailable during this period." — choose different users or change the task time.
- No collaboration notification received — ask the person to check the Collaboration Requests area at the top of the Schedule page.

Would you like this guide converted to a printable PDF or annotated with simple screenshots showing where the buttons are? 